//
//  CCCaptureManager.m
//  001-Demo
//
//  Created by CC老师 on 2019/2/16.
//  Copyright © 2019年 CC老师. All rights reserved.
//

#import "CCCaptureManager.h"
@interface CCCaptureManager ()

//时间戳
@property (nonatomic, unsafe_unretained) uint32_t timestamp;

@end

@implementation CCCaptureManager
- (instancetype)init
{
    self = [super init];
    if (self) {
        
        
    }
    return self;
}
@end
